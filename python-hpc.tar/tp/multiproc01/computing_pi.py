import os
import time
from multiprocessing import Pool


# Hint range() accepts start and end parameters
# https://docs.python.org/fr/3/library/stdtypes.html#range
def loop(num_steps, ,):
    step = 1.0/num_steps
    sum = 0
    for i in range(): # adapt range method
        x= (i+0.5)*step
        sum = sum + 4.0/(1.0+x*x)
    return sum

def Pi(num_steps, num_procs):
    size = num_steps//num_procs
    pool = Pool(processes = num_procs)
    processes = []

    iterparams= []
    for i in range(num_procs):
        start = # to complete
        end = # to complete
        iterparams.append((num_steps,start,end))

    # What is the return value of starmap ?
    # How can you transform it to get PI ?
    # See https://docs.python.org/3/library/multiprocessing.html#multiprocessing.pool.Pool
    result = pool.starmap(loop, iterparams)
    ## you need to transfrom 'result' to use it below
    pi = ###/num_steps
    print(f"Pi with {num_steps} steps is {pi}") 


if __name__ == '__main__':
    start = time.time()
    Pi(int(1e09),int(os.environ['SLURM_NPROCS'])) 
    end = time.time()
    print(f"Pi computed in {end-start} secs") 
