import os
import time
from multiprocessing import Pool



def loop(num_steps, start, end):
    step = 1.0/num_steps
    sum = 0
    for i in range(start,end):
        x= (i+0.5)*step
        sum = sum + 4.0/(1.0+x*x)
    return sum

def Pi(num_steps, num_procs):
    size = num_steps//num_procs
    pool = Pool(processes = num_procs)
    processes = []

    iterparams= []
    for i in range(num_procs):
        start = i*size
        end = (i+1)*size 
        iterparams.append((num_steps,start,end))

    value = sum(pool.starmap(loop, iterparams))
    pi = value/num_steps
    print(f"Pi with {num_steps} steps is {pi}") 


if __name__ == '__main__':
    start = time.time()
    Pi(int(1e09),int(os.environ['SLURM_NPROCS'])) 
    end = time.time()
    print(f"Pi computed in {end-start} secs") 
