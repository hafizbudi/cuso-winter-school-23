#!/bin/sh
#SBATCH --job-name multi
#SBATCH --error multi-%j.error
#SBATCH --output multi-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 6
#SBATCH --partition cpu
#SBATCH --time 00:05:00

# you can change the parameter -n to scale to higher number of cores

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python computing_pi.py
# uncomment the command below to measure CPU consumption
#time -f '%P' python  script.py
