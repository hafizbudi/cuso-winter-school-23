#!/bin/sh
#SBATCH --job-name venv
#SBATCH --error venv-%j.error
#SBATCH --output venv-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 4
#SBATCH --partition gpu
#SBATCH --time 00:40:00
#SBATCH  --gres=gpu:1

module load gcc python cuda

echo "Creating environment in: $1"
python -m venv $1
source $1/bin/activate
pip install -r requirements.txt
