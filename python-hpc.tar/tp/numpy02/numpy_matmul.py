import numpy as np
import time

N = int(4e3)

A = np.random.random((N,N))
B = np.random.random((N,N))

start = time.time()
C = np.dot(A,B)
end = time.time()

print(f"Computation took: {end-start} seconds")
