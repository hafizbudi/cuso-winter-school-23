#!/bin/sh
#SBATCH --job-name numpy
#SBATCH --error numpy-%j.error
#SBATCH --output numpy-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:05:00

# you can change the parameter --cpus-per-task to scale to higher number of cores

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python numpy_matmul.py
# uncomment the command below to measure CPU consumption
#time -f '%P' python  numpy_matmul.py
