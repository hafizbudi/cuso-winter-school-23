#!/bin/sh
#SBATCH --job-name numpy
#SBATCH --error numpy-%j.error
#SBATCH --output numpy-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:02:00

# you can change the parameter --cpus-per-task to scale to higher number of cores

source /work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/venv/bin/activate
python numpy_vdot.py
# uncomment the command below to measure CPU consumption
#time -f '%P' python  numpy_vdot.py
