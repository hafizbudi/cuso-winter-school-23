import numpy as np
import time

N = int(2e8)

v1 = np.random.random(N)
v2 = np.random.random(N)

start = time.time()

vproduct = np.vdot(v1, v2)

end = time.time()

print(f"Computation took: {end-start} seconds")
