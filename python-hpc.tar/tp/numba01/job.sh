#!/bin/sh
#SBATCH --job-name numba
#SBATCH --error numba-%j.error
#SBATCH --output numba-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:05:00

# you can change the parameter --cpus-per-task to scale to higher number of cores

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python juliaset.py


