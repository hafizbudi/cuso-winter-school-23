import time
import numpy as np
from matplotlib import pyplot as plt
from numba import njit

@njit()
def juliaset(m, size, iterations):
    for i in range(size):
        for j in range(size):
            c = -2 + 3./size*j + 1j*(1.5-3./size*i)
            z = 0
            for n in range(iterations):
                if np.abs(z) <= 10:
                    z = z*z + c
                    m[i, j] = n
                else:
                    break

size = 600
iterations = 100
m = np.zeros((size, size), dtype=np.float64)

start = time.time()
juliaset(m, size, iterations)
end = time.time()

print(f"Computation took: {end-start} seconds")
plt.matshow(m)
plt.savefig('juliaset.png')


