import numpy as np
import time

N = int(1e7)
x = np.random.random(N)
y = np.random.random(N)

r = np.zeros(N)
phi = np.zeros(N)

start = time.time()
for i in range(N):
    r[i] = np.sqrt(x[i]**2 + y[i]**2)
    phi[i] = np.arctan2(x[i], y[i])

end = time.time()

print(f"Computation took: {end-start} seconds")
