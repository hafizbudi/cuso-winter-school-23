import numpy as np
import time

N = int(1e7)
x = np.random.random(N)
y = np.random.random(N)

r = np.zeros(N)
phi = np.zeros(N)

start = time.time()

r = np.sqrt(x**2 + y**2)
phi = np.arctan2(x,y)

end = time.time()

print(f"Computation took: {end-start} seconds")
