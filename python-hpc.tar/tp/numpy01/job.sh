#!/bin/sh
#SBATCH --job-name numpy
#SBATCH --error numpy-%j.error
#SBATCH --output numpy-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:05:00

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python polar_coordinates.py
# uncomment the command below to measure memory consumption
#time -f '%Mk' python polar_coordinates.py
