from mpi4py import MPI
import socket

def loop(num_steps, start, end):
    step = 1.0/num_steps
    sum = 0
    for i in range(start,end):
        x= (i+0.5)*step
        sum = sum + 4.0/(1.0+x*x)
    return sum

def Pi(num_steps):
    total = 0
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    nprocs = comm.Get_size()

    size = num_steps // nprocs
    start = rank*size 
    end = (rank+1)*size
    
    value = loop(num_steps, start, end)
    total = comm.reduce(value, op=MPI.SUM, root=0)
    if rank==0:
        pi = total/num_steps
        print(f"Pi with {num_steps} steps is {pi}") 


if __name__ == '__main__':
    Pi(int(1e9))
