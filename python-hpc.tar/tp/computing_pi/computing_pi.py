import time

def loop(num_steps):
    step = 1.0/num_steps
    sum = 0
    for i in range(num_steps):
        x= (i +0.5)*step
        sum = sum + 4.0/(1.0+x*x)
    return sum

def Pi(num_steps ):
    start = time.time()
    sum = loop(num_steps)
    pi = sum/num_steps
    end = time.time()
    print(f"Pi with {num_steps} steps is {pi} in {end-start} secs") 
    
if __name__ == '__main__':
    Pi(int(1e09)) 
