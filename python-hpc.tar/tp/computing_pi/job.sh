#!/bin/sh
#SBATCH --job-name pi
#SBATCH --error pi-%j.error
#SBATCH --output pi-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:05:00

# you can play with -N, -n and --cpu-per-task parameters

source /work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/venv/bin/activate
#/usr/bin/time -f '%Mk' python computing_pi.py
/usr/bin/time -f '%Mk' python computing_pi_numba.py

