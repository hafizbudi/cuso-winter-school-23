import time
from dask_mpi import initialize

from dask.distributed import Client

import numpy as np
import dask.array as da

initialize()

client = Client()


def compute_pi(num_steps):
    step = 1.0/num_steps
    values = da.arange(0, 1, step, dtype=np.float64, chunks=1e6) + 0.5*step
    values = (4.0/(1.0 + values * values))
    pi = values.sum().compute()/num_steps
    print(f"Pi with {num_steps} steps is {pi}")


compute_pi(int(1e9))


