#!/bin/sh
#SBATCH --job-name cupy
#SBATCH --error cupy-%j.error
#SBATCH --output cupy-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition gpu
#SBATCH --time 00:02:00
#SBATCH  --gres=gpu:1

module load cuda
source /work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/venv/bin/activate
python computing_pi_cupy.py
