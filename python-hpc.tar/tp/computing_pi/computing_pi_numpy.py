import numpy as np
import time

def loop(num_steps):
    step = 1.0/num_steps
    values = np.arange(0,1,step,np.float64)+ 0.5*step
    
    return np.sum(4.0/(1.0+values*values))

def Pi(num_steps ):
    start = time.time()
    sum = loop(num_steps)
    pi = sum/num_steps
    end = time.time()
    print(f"Pi with {num_steps} steps is {pi} in {end-start} secs") 
    
if __name__ == '__main__':
    Pi(int(1e9))
