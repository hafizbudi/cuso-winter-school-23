from mpi4py import MPI
import numpy as np
import time


def Pi(num_steps):
    total = np.zeros(1, np.float64)
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    nprocs = comm.Get_size()
    local_points = np.zeros(int(num_steps/nprocs), np.float64)
    points = None
    size = num_steps // nprocs
    start = rank*size 
    end = (rank+1)*size

    step = 1.0/num_steps
    if rank == 0:
        points = np.arange(0,1,step,np.float64)+ 0.5*step
    comm.Scatter(points, local_points, root=0)
    
    result =  np.array(np.sum(4.0/(1.0+local_points*local_points)),np.float64)
    print(result)
    comm.Reduce(result, total, op=MPI.SUM, root=0)
    if rank==0:
        pi = total/num_steps
        print(f"Pi with {num_steps} steps is {pi[0]}") 

    
if __name__ == '__main__':
    Pi(100000000) 
