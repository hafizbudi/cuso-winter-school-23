import time 
import os
from mpi4py import MPI
import pandas as pd

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
nprocs = comm.Get_size()

## Use of pd.read_csv to read the right file
# For example:
# rank 0 have to read 1990.csv
# rank 1 have to read 1991.csv
# etc

# we only count with 10 files so we need to guarantee
# 10 ranks maximum
if nprocs > 10:
    print("Error: the maximum number of processes is 10")
    exit(1)

base_path = "/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/data/nycflights/"
df = pd.read_csv(os.path.join(base_path,f"199{rank}.csv"))

result = df.groupby("Origin")['DepDelay'].mean()
value_lga = result.to_dict()['LGA']
value_ewr = result.to_dict()['EWR']
value_jfk = result.to_dict()['JFK']

total_lga = comm.reduce(value_lga, MPI.SUM, root=0)
total_ewr = comm.reduce(value_ewr, MPI.SUM, root=0)
total_jfk = comm.reduce(value_jfk, MPI.SUM, root=0)
## to complete 

if rank == 0:
    ## to complete
    print(f"Mean value for EWR {total_ewr/nprocs}")
    print(f"Mean value for JFK {total_jfk/nprocs}")
    print(f"Mean value for LGA {total_lga/nprocs}")

