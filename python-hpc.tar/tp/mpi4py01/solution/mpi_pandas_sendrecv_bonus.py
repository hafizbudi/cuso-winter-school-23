import time
import os
from mpi4py import MPI
import pandas as pd


comm = MPI.COMM_WORLD
rank = comm.Get_rank()
nprocs = comm.Get_size()

# we only count with 10 files so we need to guarantee
# 10 ranks maximum
if nprocs > 10:
    print("Error: the maximum number of processes is 10")
    exit(1)


base_path = "/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/data/nycflights/"
df = pd.read_csv(os.path.join(base_path,f"199{rank}.csv"))

result = df.groupby("Origin")['DepDelay'].mean()

value = result.to_dict()
df_size = len(df)

if rank!=0:
    #print(f"Sending from {rank}")
    # we send local mean values
    comm.send(value, dest=0, tag = 0)
    # we send local dataframe size
    comm.send(df_size, dest=0, tag = 1) 
else:
    global_data = [value]
    df_sizes = [df_size]
    for i in range(nprocs):
        #print(f"Receiving from  {i}")
        if i != 0:
            global_data.append(comm.recv(source = i, tag= 0))
            df_sizes.append(comm.recv(source = i, tag = 1))

    # compute grouped mean

    total_ewr=0
    total_jfk=0
    total_lga=0
    for value,size in zip(global_data,df_sizes):
        total_ewr += value['EWR']*size
        total_jfk += value['JFK']*size
        total_lga += value['LGA']*size

    print(f"Mean value for EWR {total_ewr/sum(df_sizes)}")
    print(f"Mean value for JFK {total_jfk/sum(df_sizes)}")
    print(f"Mean value for LGA {total_lga/sum(df_sizes)}")
