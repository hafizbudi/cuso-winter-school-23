import os
from mpi4py import MPI
import pandas as pd

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
nprocs = comm.Get_size()

# we only count with 10 files so we need to guarantee
# 10 ranks maximum
if nprocs > 10:
    print("Error: the maximum number of processes is 10")
    exit(1)

## Use of pd.read_csv to read the right file
# For example:
# rank 0 have to read 1990.csv
# rank 1 have to read 1991.csv
# etc
base_path = "/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/data/nycflights/"
df = pd.read_csv()


result = df.groupby("Origin")['DepDelay'].mean()
value_lga = result.to_dict()['LGA']
value_ewr = # to complete
value_jfk = # to complete
total_lga = # to complete 

if rank == 0:
    print(f"Mean value for EWR {total_ewr/nprocs}")
    print(f"Mean value for JFK {total_jfk/nprocs}")
    print(f"Mean value for LGA {total_lga/nprocs}")
