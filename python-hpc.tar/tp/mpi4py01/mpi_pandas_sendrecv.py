import os
from mpi4py import MPI
import pandas as pd


comm = MPI.COMM_WORLD
rank = comm.Get_rank()
nprocs = comm.Get_size()


# we only count with 10 files so we need to guarantee
# 10 ranks maximum
if nprocs > 10:
    print("Error: the maximum number of processes is 10")
    exit(1)

## Use of pd.read_csv to read the right file
# For example:
# rank 0 has to read 1990.csv
# rank 1 has to read 1991.csv
# etc
base_path = "/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/data/nycflights/"
df = pd.read_csv()

result = df.groupby("Origin")['DepDelay'].mean()
value = result.to_dict()


if rank!=0:
    # Send data from all ranks except rank 0
else:
    global_data = [value]
    # Write a for loop to receive data from other ranks
    # Remenber that rank 0 does not send any data


    total_ewr=0
    total_jfk=0
    total_lga=0
    # Have in mind that each rank will send a dictionary
    for value in global_data:
        total_ewr += value['EWR']
        total_jfk += value['JFK']
        total_lga += value['LGA']

    print(f"Mean value for EWR {total_ewr/nprocs}")
    print(f"Mean value for JFK {total_jfk/nprocs}")
    print(f"Mean value for LGA {total_lga/nprocs}")
    
