#!/bin/sh
#SBATCH --job-name mpi4py
#SBATCH --error mpi4py-%j.error
#SBATCH --output mpi4py-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 10
#SBATCH --partition cpu
#SBATCH --time 00:05:00

module load gcc mvapich2
source /work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/venv/bin/activate
srun python #PYTHON_SCRIPT
