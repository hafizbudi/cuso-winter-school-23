#!/bin/sh
#SBATCH --job-name cupy
#SBATCH --error cupy-%j.error
#SBATCH --output cupy-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition gpu
#SBATCH --time 00:02:00
#SBATCH  --gres=gpu:1

module load cuda

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python heat_eq_numpy.py 100
#python heat_eq_numba_cuda.py
