#!/bin/sh
#SBATCH --job-name heateq
#SBATCH --error heateq-%j.error
#SBATCH --output heateq-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 1
#SBATCH --partition cpu
#SBATCH --time 00:05:00

if [ -z ${CUSO_ENV+x} ];
then
   echo "You must set CUSO_ENV variable"
   exit
fi

source $CUSO_ENV/bin/activate

python heat_eq_numpy.py 1000
# python heat_eq_numpy_explicit.py 1000
