import time
import math
import sys
import numpy as np
import matplotlib.pyplot as plt
from numba import njit, cuda


@cuda.jit(cache=True)
def init(u0, dx, dy, cx, cy, r2, Thot):

    i, j = cuda.grid(2)

    if i < u0.shape[0] and j < u0.shape[1]:
        p2 = (i * dx - cx) ** 2 + (j * dy - cy) ** 2
        if p2 < r2:
            u0[i, j] = Thot


@cuda.jit(cache=True)
def do_timestep(u0, u, D, dt, dy2, dx2):
    i, j = cuda.grid(2)

    if i < u0.shape[0] and j < u0.shape[1]:
        uxx = (u0[i + 1, j] - 2 * u0[i, j] + u0[i - 1, j]) / dx2
        uyy = (u0[i, j + 1] - 2 * u0[i, j] + u0[i, j - 1]) / dy2
        u[i, j] = u0[i, j] + dt * D * (uxx + uyy)


@cuda.jit(cache=True)
def copy_array(u0, u):
    i, j = cuda.grid(2)

    if i < u0.shape[0] and j < u0.shape[1]:
        u0[i, j] = u[i, j]


def main(dim, nsteps):

    print(f"Size: {dim}")
    w = h = dim
    dx = dy = 0.1
    D = 4
    Tcool, Thot = 300, 700
    nx, ny = int(w / dx), int(h / dy)

    dx2, dy2 = dx * dx, dy * dy

    dt = dx2 * dy2 / (2 * D * dx2 + 2 * D * dy2)
    u0 = Tcool * np.ones((nx, ny))
    u = u0.copy()

    r, cx, cy = int(w / 5), int(w / 2), int(w / 2)
    r2 = r**2

    u_device = cuda.to_device(u)
    u0_device = cuda.to_device(u0)

    # Output 4 figures at these timesteps
    mfig = [s * (nsteps // 4) for s in range(3)] + [nsteps - 1]
    fignum = 0
    fig = plt.figure()

    start = time.time()
    threadsperblock = (8, 8)
    blockspergrid_x = math.ceil(nx / threadsperblock[0])
    blockspergrid_y = math.ceil(ny / threadsperblock[1])
    blockspergrid = (blockspergrid_x, blockspergrid_y)
    init[blockspergrid, threadsperblock](u0_device, dx, dy, cx, cy, r2, Thot)

    for m in range(nsteps):

        do_timestep[blockspergrid, threadsperblock](
            u0_device, u_device, D, dt, dy2, dx2
        )
        copy_array[blockspergrid, threadsperblock](u0_device, u_device)

        if m in mfig:
            fignum += 1
            print(m, fignum)
            ax = fig.add_subplot(220 + fignum)
            u = u_device.copy_to_host()
            im = ax.imshow(u, cmap=plt.get_cmap("hot"), vmin=Tcool, vmax=Thot)
            ax.set_axis_off()
            ax.set_title("{:.1f} ms".format(m * dt * 1000))

    end = time.time()

    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.9, 0.15, 0.03, 0.7])
    cbar_ax.set_xlabel("$T$ / K", labelpad=20)
    fig.colorbar(im, cax=cbar_ax)
    print(f"Simulation took : {end-start}")
    plt.savefig("heat_transfert.png")


if __name__ == "__main__":
    dim = 10
    if len(sys.argv) > 1:
        dim = int(sys.argv[1])

    main(dim, 100)
