import time
import sys
import cupy as np
import matplotlib.pyplot as plt


def init(u0, dx, dy, cx, cy, nx, ny, r2, Thot):
    for i in range(nx):
        for j in range(ny):
            p2 = (i * dx - cx) ** 2 + (j * dy - cy) ** 2
            if p2 < r2:
                u0[i, j] = Thot


def do_timestep(u0, u, D, dt, dy2, dx2):
    u[1:-1, 1:-1] = u0[1:-1, 1:-1] + D * dt * (
        (u0[2:, 1:-1] - 2 * u0[1:-1, 1:-1] + u0[:-2, 1:-1]) / dx2
        + (u0[1:-1, 2:] - 2 * u0[1:-1, 1:-1] + u0[1:-1, :-2]) / dy2
    )
    u0 = u.copy()
    return u0, u


def main(dim, nsteps):

    print(f"Size: {dim}")
    w = h = dim
    dx = dy = 0.1
    D = 4
    Tcool, Thot = 300, 700
    nx, ny = int(w / dx), int(h / dy)

    dx2, dy2 = dx * dx, dy * dy

    dt = dx2 * dy2 / (2 * D * dx2 + 2 * D * dy2)
    u0 = Tcool * np.ones((nx, ny))
    u = u0.copy()

    r, cx, cy = int(w / 5), int(w / 2), int(w / 2)
    r2 = r**2

    # Output 4 figures at these timesteps
    mfig = [s * (nsteps // 4) for s in range(3)] + [nsteps - 1]
    fignum = 0
    fig = plt.figure()

    start = time.time()
    init(u0, dx, dy, cx, cy, nx, ny, r2, Thot)

    for m in range(nsteps):
        u0, u = do_timestep(u0, u, D, dt, dy2, dx2)

        if m in mfig:
            fignum += 1
            print(m, fignum)
            ax = fig.add_subplot(220 + fignum)
            im = ax.imshow(
                u.copy().get(), cmap=plt.get_cmap("hot"), vmin=Tcool, vmax=Thot
            )
            ax.set_axis_off()
            ax.set_title("{:.1f} ms".format(m * dt * 1000))

    end = time.time()

    fig.subplots_adjust(right=0.85)
    cbar_ax = fig.add_axes([0.9, 0.15, 0.03, 0.7])
    cbar_ax.set_xlabel("$T$ / K", labelpad=20)
    fig.colorbar(im, cax=cbar_ax)
    print(f"Simulation took : {end-start}")
    plt.savefig("heat_transfert.png")


if __name__ == "__main__":
    dim = 10
    if len(sys.argv) > 1:
        dim = int(sys.argv[1])

    main(dim, 100)
