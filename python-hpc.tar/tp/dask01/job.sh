#!/bin/sh
#SBATCH --job-name dask-mpi
#SBATCH --error dask-%j.error
#SBATCH --output dask-%j.out
#SBATCH -N 1
#SBATCH --cpus-per-task 1
#SBATCH -n 4
#SBATCH --partition cpu
#SBATCH --time 00:05:00

module load gcc mvapich2
source /work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/venv/bin/activate
srun -n 4 python pandas_distributed.py
