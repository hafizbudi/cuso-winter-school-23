import os
import time
from dask_mpi import initialize

from dask.distributed import Client

import dask.dataframe as dd

initialize()

client = Client()

base_path = '/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/'

start = time.time()

ddf = dd.read_csv(os.path.join(base_path,'data', 'nycflights','*.csv'),
                  parse_dates={'Date': [0, 1, 2]}, # Here we parse the year, month and day into date
                 dtype={'TailNum': str,
                        'CRSElapsedTime': float,
                        'Cancelled': bool})

# Group by Origin and compute mean of DepDelay column 
global_mean = # to complete
# do not forget to trigger computation
print(f"Global mean is: {}")
end = time.time()
print(f"Computation took: {end-start}")

client.close()
