import os
import time
from dask_mpi import initialize

from dask.distributed import Client

import numpy as np
import dask.dataframe as dd

initialize()

client = Client()

base_path = '/work/TRAINING/UNIL/CTR/rfabbret/cours_hpc/python_hpc/'

start = time.time()

ddf = dd.read_csv(os.path.join(base_path,'data', 'nycflights','*.csv'),
                  parse_dates={'Date': [0, 1, 2]}, # Here we parse the year, month and day into date
                 dtype={'TailNum': str,
                        'CRSElapsedTime': float,
                        'Cancelled': bool})

global_mean = ddf.groupby("Origin")['DepDelay'].mean()
print(f"Global mean is: {global_mean.compute()}")
end = time.time()
print(f"Computation took: {end-start}")

client.close()
