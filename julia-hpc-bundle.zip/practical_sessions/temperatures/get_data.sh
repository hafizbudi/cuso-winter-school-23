#!/bin/bash

set -e

mkdir -p data
cd data
wget --recursive --no-parent --no-directories --timestamping -R "index*" -R "robots.txt" https://www.ncei.noaa.gov/pub/data/uscrn/products/heat01/
(echo "---" ; echo; echo "USCRN_stations:" && for i in $(ls -1 *csv); do echo "  - station: $(echo $i | cut -f2- -d_| cut -f1 -d.)"; echo "    state: $(echo $i |cut -f1 -d_ |cut -f2 -d-)"; echo "    file: $i"; done) > ../USCRN_stations.yaml
cd ..
