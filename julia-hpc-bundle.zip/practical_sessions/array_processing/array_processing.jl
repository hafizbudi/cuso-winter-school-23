using BenchmarkTools

function serial_processing(a, n)
  for i in 1:n
    a[i] = sin(i * i) / atan(2 * i)
  end
end

#function parallel_processing(a, n)
#
#end

n = 10_000_000
a = zeros(Float64, n)
@btime serial_processing($a, $n) 
#@btime parallel_processing($a, $n) 
