using BenchmarkTools

function vecsum(x, y)
    s = zero(eltype(x))
    for i=eachindex(x)
        s += x[i]*y[i]
    end
    return s
end

function vecsum_simd(x, y)
    s = zero(eltype(x))
    @simd for i = eachindex(x)
        s += x[i] * y[i]
    end
    return s
end

x = rand(Float32, 10000)
y = rand(Float32, 10000)
s = 0.0
@btime s = vecsum($x, $y)
@btime s = vecsum_simd($x, $y)
