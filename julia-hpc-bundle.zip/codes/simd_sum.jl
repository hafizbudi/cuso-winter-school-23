using BenchmarkTools
using SIMD

function naive_sum(x::Vector{Float64})
  s = 0.0
  for i = 1:length(x)
    s = s + x[i]
  end
  return s
end

println("Naive sum")
a = [1.0, 2.0 , 3.0, 4.0]
@btime naive_sum($a)
println("Vectorized sum")
b = Vec{4, Float64}((1.0, 2.0, 3.0, 4.0))
@btime sum($b)
