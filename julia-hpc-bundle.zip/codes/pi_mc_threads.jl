using Random
using Base.Threads
using BenchmarkTools

function darts_in_circle(n, rng=Random.GLOBAL_RNG)
  inside = 0
  for i in 1:n
    if (rand(rng)^2 + rand(rng)^2) <= 1
      inside += 1
    end
  end
  return inside
end

function pi_serial(n)
  return 4 * darts_in_circle(n) / n
end

function pi_threads(n)
  rnglist = [MersenneTwister() for i in 1:nthreads()]
  inside = zeros(Int, nthreads())
  @threads for i in 1:nthreads()
    rng = rnglist[threadid()]
    inside[threadid()] = darts_in_circle(n / nthreads(), rng)
  end
  return 4 * sum(inside) / (n)
end

println("Pi serial")
println(pi_serial(100_000_000))
@btime pi_serial(100_000_000)

println("Pi parallel")
println(pi_threads(100_000_000))
@btime pi_threads(100_000_000)
