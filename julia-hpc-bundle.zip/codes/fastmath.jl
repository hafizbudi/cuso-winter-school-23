using BenchmarkTools

function sum_diff(x)
  n = length(x)
  d = 1/(n-1)
  s = zero(eltype(x))
  s +=  (x[2] - x[1]) / d
  for i in 2:length(x)-1
    s += (x[i+1] - x[i]) / (2*d)
  end
  s += (x[n] - x[n-1])/d
end

function sum_diff_fast(x)
  n=length(x)
  d = 1/(n-1)
  s = zero(eltype(x))
  @fastmath s += (x[2] - x[1]) / d
  @fastmath for i in 2:n-1
    s += (x[i+1] - x[i]) / (2*d)
  end
  @fastmath s += (x[n] - x[n-1])/d
end

t = rand(10000)
println("Without fastmath")
@btime sum_diff($t)
println("With fastmath")
@btime sum_diff_fast($t)
