using CUDA
using BenchmarkTools

function pi_serial(n)
  inside = 0
  for i in 1:n
    x, y = rand(), rand()
    inside += ((x^2 + y^2) <= 1)
  end
  return 4 * inside / n
end

function pi_gpu32(n)
   return 4 * sum((CUDA.rand(Float32, n).^2 .+ CUDA.rand(Float32, n).^2) .<= 1) / n
end

function pi_gpu64(n)
   return 4 * sum((CUDA.rand(Float64, n).^2 .+ CUDA.rand(Float64, n).^2) .<= 1) / n
end

println("Pi serial")
@btime pi_serial(100_000_000)
println("Pi GPU 32 bits")
@btime CUDA.@sync pi_gpu32(100_000_000)
println("Pi GPU 64 bits")
@btime CUDA.@sync pi_gpu64(100_000_000)
