using Base.Threads

println("Compute without threads")
@time for i in 1:8
    sin.(rand(5000, 5000))
end

println("Compute with threads")
@time @threads for i in 1:8
    sin.(rand(5000, 5000))
end
