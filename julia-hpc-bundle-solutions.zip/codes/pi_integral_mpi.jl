using MPI

function loop(istart, iend, step)
  sum = 0.0
  for i in istart:iend
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum
end

function pi_mpi(num_steps, rank, size)
  step = 1.0 / num_steps
  chunk_size = num_steps ÷ size
  istart = rank * chunk_size
  iend = istart + (chunk_size - 1)
  r = loop(istart, iend, step)
  return r / num_steps
end

MPI.Init()
const root = 0
const n = 100_000_000
const comm = MPI.COMM_WORLD
const rank = MPI.Comm_rank(comm) 
const size = MPI.Comm_size(comm)

r = MPI.Reduce(pi_mpi(n, rank, size), (+), root, comm)

if rank == root
  println("Pi MPI")
  println(r)
end
MPI.Finalize()
