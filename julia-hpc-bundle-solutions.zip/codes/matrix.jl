using BenchmarkTools
using LinearAlgebra

A = rand(5000,5000)
B = rand(5000,5000)
C = similar(A)

println("Matrix multiplication with 1 thread")
BLAS.set_num_threads(1)
@btime mul!($C, $A, $B)

println("Matrix multiplication with 2 threads")
BLAS.set_num_threads(2)
@btime mul!($C, $A, $B)

println("Matrix multiplication with 4 threads")
BLAS.set_num_threads(4)
@btime mul!($C, $A, $B)
