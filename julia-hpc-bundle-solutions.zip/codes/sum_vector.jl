using BenchmarkTools

function sum_vectors!(x, y, z)
  n = length(x)
  for i in 1:n
    @inbounds x[i] = y[i] + z[i]
  end
end

function sum_vectors_simd!(x, y, z)
  n = length(x)
  @simd for i in 1:n
    @inbounds x[i] = y[i] + z[i]
  end
end

a = zeros(Float64, 1_000_000)
b = rand(Float64, 1_000_000)
c = rand(Float64, 1_000_000)

println("Sum without vectorization")
@btime sum_vectors!($a, $b, $c)
println("Sum with vectorization")
@btime sum_vectors_simd!($a, $b, $c)
