using Distributed
using BenchmarkTools


@everywhere function loop(istart, iend, step)
  sum = 0.0
  for i in istart:iend
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum  
end

function pi_serial(num_steps)
  step = 1.0 / num_steps
  return loop(0, num_steps - 1, step) / num_steps
end

function pi_pmap(num_steps)
  step = 1.0 / num_steps
  chunk_size = num_steps ÷ (nprocs() - 1)
  vstart = collect(range(0, num_steps - chunk_size, step=chunk_size))
  vend = vstart .+ (chunk_size - 1)
  vstep = fill(step, nprocs() - 1)
  r = sum(pmap((istart, iend, step)->loop(istart, iend, step), vstart, vend, vstep))
  return r / num_steps
end

function pi_distributed(num_steps)
  step = 1.0 / num_steps
  chunk_size = num_steps ÷ (nprocs() - 1)
  r = @distributed (+) for i in 0:(nprocs() - 2)
    istart = i * chunk_size
    iend = istart + (chunk_size - 1)
    loop(istart, iend, step)
  end
  return r / num_steps
end

function pi_distributed_v2(num_steps)
  step = 1.0 / num_steps
  chunk_size = 1000
  chunks = num_steps ÷ chunk_size
  r = @distributed (+) for i in 0:chunks
    istart = i * chunk_size
    iend = istart + (chunk_size - 1)
    loop(istart, iend, step)
  end
  return r / num_steps
end

println("Pi serial")
#println(pi_serial(100_000_000))
@btime pi_serial(1_000_000_000)

println("Pi pmap")
#println(pi_pmap(100_000_000))
@btime pi_pmap(1_000_000_000)

println("Pi distributed")
#println(pi_distributed(1_000_000_000))
@btime pi_distributed(1_000_000_000)

println("Pi distributed V2")
#println(pi_distributed_v2(1_000_000_000))
@btime pi_distributed_v2(1_000_000_000)
