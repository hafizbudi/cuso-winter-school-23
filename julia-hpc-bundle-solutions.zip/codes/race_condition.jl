using Base.Threads

function sum_serial(n)
  acc = 0
  for i in 1:n
    acc += 1
  end
  return acc
end

function sum_threads(n)
  acc = 0
  @threads for i in 1:n
    acc += 1
  end
  return acc
end

println("Sum serial " * string(sum_serial(100_000)))
println("Sum threads " * string(sum_threads(100_000)))
