
println("Sleep without tasks")
@time for i in 1:5
    sleep(1)
end

println("Sleep with tasks")
@time @sync for i in 1:5
    @async sleep(1)
end

println("Compute without tasks")
@time for i in 1:100
    sin.(rand(1000, 1000))
end

println("Compute with tasks")
@time @sync for i in 1:100
    @async sin.(rand(1000, 1000))
end
