using BenchmarkTools
using StaticArrays

a = [1, 2, 3, 4]
b = SVector(1, 2, 3, 4)

println("Using regular array")
@btime $a*$a'

println("Using static array")
@btime $b*$b'
