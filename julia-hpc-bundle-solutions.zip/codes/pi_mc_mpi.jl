using MPI

function darts_in_circle(n)
  inside = 0
  for i in 1:n
    if (rand()^2 + rand()^2) <= 1
      inside += 1
    end
  end
  return inside
end

MPI.Init()
const root = 0
const n = 100_000_000
const comm = MPI.COMM_WORLD
const rank = MPI.Comm_rank(comm) 
const size = MPI.Comm_size(comm)


sum = MPI.Reduce(darts_in_circle(n), (+), root, comm)

if rank == root
  println("Pi MPI")
  println(4 * sum / n)
end
MPI.Finalize()
