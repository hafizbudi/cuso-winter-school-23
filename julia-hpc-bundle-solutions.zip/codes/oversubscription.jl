using Base.Threads
using BenchmarkTools

function matmul_serial(x)
  first_num = zeros(length(x))
  for i in eachindex(x)
    @inbounds first_num[i] = (x[i]'*x[i])[1]
  end
  return first_num
end

function matmul_thread(x)
  first_num = zeros(length(x))
  @threads for i in eachindex(x)
    @inbounds first_num[i] = (x[i]'*x[i])[1]
  end
  return first_num
end

m = [rand(1000, 1000) for _ in 1:100]
@btime matmul_serial($m)
@btime matmul_thread($m)
