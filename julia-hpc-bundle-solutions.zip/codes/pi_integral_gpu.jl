using BenchmarkTools
using CUDA

function pi(num_steps)
  step = 1.0 / num_steps
  sum = 0.0
  for i in 0:num_steps - 1
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum / num_steps
end

function pi_gpu(num_steps)
  step = 1.0 / num_steps
  values = CuArray{Float64}(undef, num_steps)
  values[:] .= 4.0 ./ (1.0 .+ (((0:(num_steps - 1)) .+ 0.5) .* step).^2) 
  return sum(values) / num_steps
end


function kernel!(values, step)
  i = (blockIdx().x - 1) * blockDim().x + threadIdx().x
  values[i] = 4.0 / (1.0 + ((i + 0.5) * step)^2)
  return nothing 
end

function pi_gpu_kernel(num_steps)
  step = 1.0 / num_steps
  values = CuArray{Float64}(undef, num_steps)
  threads_per_block = 1024
  blocks = num_steps ÷ threads_per_block
  @cuda threads=threads_per_block blocks=blocks kernel!(values, step)
  return sum(values) / num_steps
end

#@btime pi(5_120_000_000);
#@btime CUDA.@sync pi_gpu(5_120_000_000);
#@btime CUDA.@sync pi_gpu_kernel(5_120_000_000);

pi(1_024)
@time pi(5_120_000_000);
CUDA.@sync pi_gpu(1_024)
@CUDA.time pi_gpu(5_120_000_000);
CUDA.@sync pi_gpu_kernel(1_024)
@CUDA.time pi_gpu_kernel(5_120_000_000);
