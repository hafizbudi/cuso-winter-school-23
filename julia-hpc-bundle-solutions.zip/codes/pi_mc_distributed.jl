using Distributed
using BenchmarkTools

@everywhere function darts_in_circle(n)
  inside = 0
  for i in 1:n
    if (rand()^2 + rand()^2) <= 1
      inside += 1
    end
  end
  return inside
end

function pi_serial(n)
  return 4 * darts_in_circle(n) / n
end

function pi_pmap(n)
  r = sum(pmap((x)->darts_in_circle(n / nprocs()), 1:nprocs()))
  return 4 * r / n
end

function pi_distributed(n)
  r = @distributed (+) for i in 1:nprocs()
    darts_in_circle(n/nprocs())
  end
  return 4 * r / n
end

function pi_distributed_v2(n)
  r = @distributed (+) for i in 1:n/100
    darts_in_circle(100)
  end
  return 4 * r / n
end

println("Pi serial")
println(pi_serial(100_000_000))
@btime pi_serial(100_000_000)

println("Pi pmap")
println(pi_pmap(100_000_000))
@btime pi_pmap(100_000_000)

println("Pi distributed")
println(pi_distributed(100_000_000))
@btime pi_distributed(100_000_000)

println("Pi distributed V2")
println(pi_distributed_v2(100_000_000))
@btime pi_distributed_v2(100_000_000)
