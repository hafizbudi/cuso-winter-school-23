using BenchmarkTools

function prefix_bounds(a, b)
  for i in 2:size(a, 1)
    a[i] = b[i-1] + b[i]
  end
end
function prefix_inbounds(a, b)
  @inbounds for i in 2:size(a, 1)
    a[i] = b[i-1] + b[i]
  end
end

a = zeros(Float64, 1000)
b = rand(1000)
println("With bounds checking")
@btime prefix_bounds($a, $b)
println("Without bounds checking")
@btime prefix_inbounds($a, $b)
