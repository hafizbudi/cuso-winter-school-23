using BenchmarkTools

p = 2
const p2 = 2

function pow_array(x)
  s = 0.0
  for y in x
    s = s + y^p
  end
  return s
end

function pow_array_const(x)
  s = 0.0
  for y in x
    s = s + y^p2
  end
  return s
end

t = rand(100000);
println("Global var")
@btime pow_array($t)
println("Const var")
@btime pow_array_const($t)
