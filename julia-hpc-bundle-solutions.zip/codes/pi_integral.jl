using BenchmarkTools
using Folds
using LoopVectorization
:x
function pi(num_steps)
  step = 1.0 / num_steps
  sum = 0.0
  for i in 0:num_steps - 1
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum
end

function pi_folds(num_steps)
  step = 1.0 / num_steps
  sum = Folds.reduce(+, (4.0 / (1.0 + ((i + 0.5) * step)^2) for i in 0:num_steps - 1))
  return sum
end

function pi_tturbo(num_steps)
  step = 1.0 / num_steps
  sum = 0.0
  @tturbo for i in 0:num_steps - 1
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum
end

@btime pi(1_000_000_000)
@btime pi_folds(1_000_000_000)
@btime pi_tturbo(1_000_000_000)
