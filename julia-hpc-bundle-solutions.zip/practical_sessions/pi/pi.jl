using BenchmarkTools
using Base.Threads

function pi(num_steps)
  step = 1.0 / num_steps
  sum = 0.0
  for i in 0:num_steps - 1
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum / num_steps
end

function pi_parallel(num_steps)
###
end

@btime pi(1_000_000_000);
@btime pi_parallel(1_000_000_000);
