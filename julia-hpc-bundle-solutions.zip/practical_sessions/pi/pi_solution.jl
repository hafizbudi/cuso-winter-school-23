using BenchmarkTools
using Base.Threads

function pi(num_steps)
  step = 1.0 / num_steps
  sum = 0.0
  for i in 0:num_steps - 1
    sum += 4.0 / (1.0 + ((i + 0.5) * step)^2)
  end
  return sum / num_steps
end

function pi_parallel(num_steps)
  step = 1.0 / num_steps
  local_sum = zeros(nthreads())
  chunk_size = num_steps ÷ nthreads()
  @threads for t in 1:nthreads()
    istart = chunk_size * (threadid() - 1)
    iend = istart + chunk_size - 1
    for i in istart:iend
      local_sum[t] += 4.0 / (1.0 + ((i + 0.5) * step)^2)
    end
  end
  return sum(local_sum) / num_steps
end

@btime pi(1_000_000_000);
@btime pi_parallel(1_000_000_000);
