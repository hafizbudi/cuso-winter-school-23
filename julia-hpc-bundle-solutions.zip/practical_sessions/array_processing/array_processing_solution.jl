using BenchmarkTools
using Base.Threads

function serial_processing(a, n)
  for i in 1:n
    a[i] = sin(i * i) / atan(2 * i)
  end
end

function parallel_processing(a, n)
  @threads for i in 1:n
    a[i] = sin(i * i) / atan(2 * i)
  end
end

n = 10_000_000
a = zeros(Float64, n)
@btime serial_processing($a, $n) 
@btime parallel_processing($a, $n) 
