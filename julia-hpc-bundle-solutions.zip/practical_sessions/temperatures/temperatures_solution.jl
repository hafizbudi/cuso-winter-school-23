using Distributed
using YAML
@everywhere using CSV
@everywhere const data_dir = "data"

@everywhere function process_station(station_entry)
  min = 99.9
  max = -99.9
  date_min = 0
  date_max = 0
  file = data_dir * "/" * station_entry["file"]
  reader = CSV.File(file)
  for row in reader
    temperature = row.DRY_BULB_TEMPERATURE_C
    if !ismissing(temperature)
      if temperature < min
        min = temperature
        date_min = row.DATE_TIME
      end
      if temperature > max
        max = temperature
        date_max = row.DATE_TIME
      end
    end
  end
  return Dict(station_entry["station"] => (min, max, date_min, date_max))
end

data = YAML.load_file("USCRN_stations.yaml")
station_entries = [entry for entry in data["USCRN_stations"]]

tmp_results = pmap(process_station, station_entries)
results = Dict()
for result in tmp_results
    merge!(results, result)
end

min_temp_station = reduce((x, y) -> results[x][1] < results[y][1] ? x : y, keys(results))
max_temp_station = reduce((x, y) -> results[x][2] > results[y][2] ? x : y, keys(results))
println("Minimum temperature in $min_temp_station: $(results[min_temp_station][1]) (date: $(results[min_temp_station][3]))")
println("Maximum temperature in $max_temp_station: $(results[max_temp_station][2]) (date: $(results[max_temp_station][4]))")
