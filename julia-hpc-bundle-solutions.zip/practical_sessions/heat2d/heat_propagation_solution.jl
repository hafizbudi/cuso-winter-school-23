using BenchmarkTools
using Plots
using Base.Threads
using CUDA
CUDA.allowscalar(false)

function init(u0, u, Tcool, Thot)
    u0[:,:] .= Tcool
    u0[1, :] .= Thot
    u0[:, 1] .= Thot
    u0[size(u0, 1), :] .= Thot
    u0[:, size(u0, 2)] .= Thot
    u .= u0
end

function run_cpu_serial(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    for m in 1:nsteps
        for i in 2:nx-1
            for j in 2:ny-1
                uxx = (u0[i + 1, j] - 2 * u0[i, j] + u0[i-1, j]) / dx2
                uyy = (u0[i, j + 1] - 2 * u0[i, j] + u0[i, j-1]) / dy2
                u[i,j] = u0[i, j] + dt * D * (uxx + uyy)
            end
        end
        u0 .= u
        if plot
            if m in mfig
                p = heatmap(1:size(u0, 1), 1:size(u0, 2), u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function run_cpu_threads(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    for m in 1:nsteps
        @threads for i in 2:nx-1
            for j in 2:ny-1
                uxx = (u0[i + 1, j] - 2 * u0[i, j] + u0[i-1, j]) / dx2
                uyy = (u0[i, j + 1] - 2 * u0[i, j] + u0[i, j-1]) / dy2
                u[i,j] = u0[i, j] + dt * D * (uxx + uyy)
            end
        end
        u0 .= u
        if plot
            if m in mfig
                p = heatmap(1:size(u0, 1), 1:size(u0, 2), u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function run_cpu_vect(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    for m in 1:nsteps
        u[2:nx-1, 2:ny-1] .= u0[2:nx-1, 2:ny-1] + dt * D * (((u0[3:nx, 2:ny-1] - 2 * u0[2:nx-1, 2:ny-1] + u0[1:nx-2, 2:ny-1]) / dx2) + ((u0[2:nx-1, 3:ny] - 2 * u0[2:nx-1, 2:ny-1] + u0[2:nx-1, 1:ny-2]) / dy2))
        u0 .= u
        if plot
            if m in mfig
                p = heatmap(1:size(u0, 1), 1:size(u0, 2), u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function run_cpu_vect_views(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    for m in 1:nsteps
        @views u[2:nx-1, 2:ny-1] .= u0[2:nx-1, 2:ny-1] + dt * D * (((u0[3:nx, 2:ny-1] - 2 * u0[2:nx-1, 2:ny-1] + u0[1:nx-2, 2:ny-1]) / dx2) + ((u0[2:nx-1, 3:ny] - 2 * u0[2:nx-1, 2:ny-1] + u0[2:nx-1, 1:ny-2]) / dy2))
        u0 .= u
        if plot
            if m in mfig
                p = heatmap(1:size(u0, 1), 1:size(u0, 2), u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function run_gpu(cpu_u0, cpu_u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    u0 = CuArray(cpu_u0)
    u = CuArray(cpu_u)
    for m in 1:nsteps
        u[2:nx-1,2:ny-1] .= u0[2:nx-1, 2:ny-1] + dt * D * (((u0[3:nx, 2:ny-1] - 2 * u0[2:nx-1, 2:ny-1] + u0[1:nx-2, 2:ny-1]) / dx2) + ((u0[2:nx-1, 3:ny] - 2 * u0[2:nx-1, 2:ny-1] + u0[2:nx-1, 1:ny-2]) / dy2))
        u0 .= u
        if plot
            if m in mfig
                cpu_u0 = Array(u0)
                p = heatmap(1:size(cpu_u0, 1), 1:size(cpu_u0, 2), cpu_u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function run_gpu_views(cpu_u0, cpu_u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    u0 = CuArray(cpu_u0)
    u = CuArray(cpu_u)
    for m in 1:nsteps
        @views u[2:nx-1,2:ny-1] .= u0[2:nx-1, 2:ny-1] + dt * D * (((u0[3:nx, 2:ny-1] - 2 * u0[2:nx-1, 2:ny-1] + u0[1:nx-2, 2:ny-1]) / dx2) + ((u0[2:nx-1, 3:ny] - 2 * u0[2:nx-1, 2:ny-1] + u0[2:nx-1, 1:ny-2]) / dy2))
        u0 .= u
        if plot
            if m in mfig
                cpu_u0 = Array(u0)
                p = heatmap(1:size(cpu_u0, 1), 1:size(cpu_u0, 2), cpu_u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end

function _gpu_kernel!(u0, u, D, nx, ny, dx2, dy2, dt)
    i = (blockIdx().x-1) * blockDim().x + threadIdx().x
    j = (blockIdx().y-1) * blockDim().y + threadIdx().y
    if (i > 1 && i < size(u0, 1) && j > 1 && j < size(u0, 2))
        @inbounds uxx = (u0[i + 1, j] - 2 * u0[i, j] + u0[i-1, j]) / dx2
        @inbounds uyy = (u0[i, j + 1] - 2 * u0[i, j] + u0[i, j-1]) / dy2
        @inbounds u[i,j] = u0[i, j] + dt * D * (uxx + uyy)
    end
    return nothing
end

function run_gpu_kernel(cpu_u0, cpu_u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    u0 = CuArray(cpu_u0)
    u = CuArray(cpu_u)
    threads_per_block = (32,8)
    blocks  = (size(u0, 1) ÷ threads_per_block[1], size(u0, 2) ÷ threads_per_block[2])
    for m in 1:nsteps
        @cuda threads=threads_per_block blocks=blocks _gpu_kernel!(u0, u, D, nx, ny, dx2, dy2, dt)
        u0 .= u
        if plot
            if m in mfig
                cpu_u0 = Array(u0)
                p = heatmap(1:size(cpu_u0, 1), 1:size(cpu_u0, 2), cpu_u0, xlabel="x values", ylabel="y values", title="My title", c = :thermal, legend = false)
                gui(p)
            end
        end
    end
end


function main()
    w = h = 256
    dx = dy = 0.1
    D = 4
    Tcool = 0.0
    Thot = 300.0
    nx = floor(Int, w / dx)
    ny = floor(Int, h / dy)
    dx2 = dx^2
    dy2 =  dy^2
    dt = dx2 * dy2 / (2 * D * dx2 + 2 * D * dy2)
    nsteps = 100
    plot = false
    u0 = Array{Float64}(undef, nx, ny)
    u = Array{Float64}(undef, nx, ny)
    mfig = [i*10 for i in 1:nsteps/10]

    println("CPU serial")
    init(u0, u, Tcool, Thot)
    run_cpu_serial(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
    @time run_cpu_serial(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    println("CPU threaded")
    init(u0, u, Tcool, Thot)
    run_cpu_threads(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
    @time run_cpu_threads(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    println("CPU vect")
    init(u0, u, Tcool, Thot)
    run_cpu_vect(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
    @time run_cpu_vect(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    println("CPU vect views")
    init(u0, u, Tcool, Thot)
    run_cpu_vect_views(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
    @time run_cpu_vect_views(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    if has_cuda()
        println("GPU broadcast")
        init(u0, u, Tcool, Thot)
        run_gpu(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
        CUDA.@time run_gpu(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
        println("GPU broadcast views")
        init(u0, u, Tcool, Thot)
        run_gpu_views(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
        CUDA.@time run_gpu_views(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
        println("GPU kernel")
        init(u0, u, Tcool, Thot)
        run_gpu_kernel(u0, u, D, nx, ny, dx2, dy2, dt, 1, mfig, plot)
        CUDA.@time run_gpu_kernel(u0, u, D, nx, ny, dx2, dy2, dt, nsteps, mfig, plot)
    end
end

main()